../src/abbrev.c:14:6: warning: promoted type 'int' of K&R function parameter is not compatible with the parameter type 'char' declared in a previous prototype [-Wknr-promoted-parameter]
char c;         /* character to add to current word buffer */
     ^
../h/eproto.h:481:38: note: previous declaration is here
extern VOID PASCAL NEAR ab_save(char c);
                                     ^
../src/abbrev.c:227:11: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
        register llength;       /* length of the current line being examined */
        ~~~~~~~~ ^
../src/abbrev.c:267:1: warning: non-void function does not return a value in all control paths [-Wreturn-type]
}
^
3 warnings generated.
../src/basic.c:22:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR gotobol(f, n)
            ^
../src/basic.c:37:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR backchar(f, n)
            ^
../src/basic.c:66:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR gotoeol(f, n)
            ^
../src/basic.c:81:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR forwchar(f, n)
            ^
../src/basic.c:105:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR gotoline(f, n)      /* move to a particular line.
            ^
../src/basic.c:140:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR gotobob(f, n)
            ^
../src/basic.c:156:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR gotoeob(f, n)
            ^
../src/basic.c:173:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR forwline(f, n)
            ^
../src/basic.c:217:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR backline(f, n)
            ^
../src/basic.c:256:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR gotobop(f, n) /* go back to the beginning of the current paragraph
            ^
../src/basic.c:322:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR gotoeop(f, n) /* go forword to the end of the current paragraph
            ^
../src/basic.c:436:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR forwpage(f, n)
            ^
../src/basic.c:469:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR backpage(f, n)
            ^
../src/basic.c:501:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR setmark(f, n)
            ^
../src/basic.c:522:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR remmark(f, n)
            ^
../src/basic.c:545:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR swapmark(f, n)
            ^
../src/basic.c:578:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR gotomark(f, n)
            ^
17 warnings generated.
../src/bind.c:14:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR help(f, n)  /* give me some help!!!!
            ^
../src/bind.c:28:17: warning: passing 'const char *' to parameter of type 'char *' discards qualifiers [-Wincompatible-pointer-types-discards-qualifiers]
                fname = flook(pathname[1], FALSE);
                              ^~~~~~~~~~~
../h/eproto.h:89:38: note: passing argument to parameter 'fname' here
extern char *PASCAL NEAR flook(char *fname, int hflag);
                                     ^
../src/bind.c:54:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR deskey(f, n)        /* describe the command for a certain key */
            ^
../src/bind.c:84:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR bindtokey(f, n)
            ^
../src/bind.c:183:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR macrotokey(f, n)
            ^
../src/bind.c:261:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR unbindkey(f, n)
            ^
../src/bind.c:289:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR unbindchar(c)
            ^
../src/bind.c:362:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR desbind(f, n)
            ^
../src/bind.c:370:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR apro(f, n)  /* Apropos (List functions that match a substring) */
            ^
../src/bind.c:386:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR buildlist(type, mstring)  /* build a binding list (limited or full) */
            ^
../src/bind.c:522:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR strinc(source, sub) /* does source include sub? */
            ^
../src/bind.c:569:16: warning: passing 'char [128]' to parameter of type 'unsigned char *' converts between pointers to integer types with different sign [-Wpointer-sign]
                return(stock(tok));
                             ^~~
../h/eproto.h:470:54: note: passing argument to parameter 'keyname' here
extern unsigned int PASCAL NEAR stock(unsigned char *keyname);
                                                     ^
../src/bind.c:582:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR startup(sfname)
            ^
../src/bind.c:600:17: warning: passing 'const char *' to parameter of type 'char *' discards qualifiers [-Wincompatible-pointer-types-discards-qualifiers]
                fname = flook(pathname[0], TRUE);
                              ^~~~~~~~~~~
../h/eproto.h:89:38: note: passing argument to parameter 'fname' here
extern char *PASCAL NEAR flook(char *fname, int hflag);
                                     ^
../src/bind.c:1003:36: warning: passing 'char *' to parameter of type 'unsigned char *' converts between pointers to integer types with different sign [-Wpointer-sign]
        bindname = getfname(getbind(stock(skey)));
                                          ^~~~
../src/bind.c:1005:12: warning: assigning to 'char *' from 'const char []' discards qualifiers [-Wincompatible-pointer-types-discards-qualifiers]
                bindname = errorm;
                         ^ ~~~~~~
16 warnings generated.
../src/buffer.c:22:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR usebuffer(f, n)
            ^
../src/buffer.c:44:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR nextbuffer(f, n)    /* switch to the next buffer in the buffer list */
            ^
../src/buffer.c:69:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR swbuffer(bp)        /* make buffer BP current */
            ^
../src/buffer.c:154:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR killbuffer(f, n)
            ^
../src/buffer.c:173:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR popbuffer(f, n)
            ^
../src/buffer.c:218:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR zotbuf(bp)  /* kill the buffer pointed to by bp */
            ^
../src/buffer.c:274:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR namebuffer(f,n)     /*      Rename the current buffer       */
            ^
../src/buffer.c:309:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR listbuffers(f, n)
            ^
../src/buffer.c:330:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR makelist(iflag)
            ^
../src/buffer.c:491:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR anycb()
            ^
../src/buffer.c:601:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR bclear(bp)
            ^
../src/buffer.c:627:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR unmark(f, n)        /* unmark the current buffers change flag */
            ^
12 warnings generated.
../src/char.c:23:15: warning: promoted type 'int' of K&R function parameter is not compatible with the parameter type 'char' declared in a previous prototype [-Wknr-promoted-parameter]
register char ch;
              ^
../h/eproto.h:182:39: note: previous declaration is here
extern int PASCAL NEAR is_letter(char ch);
                                      ^
../src/char.c:36:15: warning: promoted type 'int' of K&R function parameter is not compatible with the parameter type 'char' declared in a previous prototype [-Wknr-promoted-parameter]
register char ch;
              ^
../h/eproto.h:183:38: note: previous declaration is here
extern int PASCAL NEAR is_lower(char ch);
                                     ^
../src/char.c:49:15: warning: promoted type 'int' of K&R function parameter is not compatible with the parameter type 'char' declared in a previous prototype [-Wknr-promoted-parameter]
register char ch;
              ^
../h/eproto.h:186:38: note: previous declaration is here
extern int PASCAL NEAR is_upper(char ch);
                                     ^
3 warnings generated.
../src/crypt.c:19:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR setekey(f, n)       /* reset encryption key of current buffer */
            ^
1 warning generated.
../src/display.c:253:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR vttidy()
            ^
../src/display.c:260:1: warning: non-void function does not return a value [-Wreturn-type]
}
^
../src/display.c:267:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR vtmove(row, col)
            ^
../src/display.c:274:1: warning: non-void function does not return a value [-Wreturn-type]
}
^
../src/display.c:283:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR vtputc(c)
            ^
../src/display.c:335:1: warning: non-void function does not return a value [-Wreturn-type]
}
^
../src/display.c:341:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR vteeol()
            ^
../src/display.c:351:1: warning: non-void function does not return a value [-Wreturn-type]
}
^
../src/display.c:486:4: warning: add explicit braces to avoid dangling else [-Wdangling-else]
                        else
                        ^
../src/display.c:2165:1: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
winch_vtresize(rows, cols)
^
../src/display.c:2224:1: warning: non-void function does not return a value [-Wreturn-type]
}
^
11 warnings generated.
../src/dolock.c:458:1: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
dolhello()
^
../src/dolock.c:460:1: warning: non-void function does not return a value [-Wreturn-type]
}
^
2 warnings generated.
In file included from ../src/eval.c:11:
../h/evar.h:216:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "abbrev", MONAMIC,      /* look up abbreviation */
        ^~~~~~~~~~~~~~~~~
        {                }
../h/evar.h:217:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "abs", MONAMIC,         /* absolute value of a number */
        ^~~~~~~~~~~~~~
        {             }
../h/evar.h:218:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "add", DYNAMIC,         /* add two numbers together */
        ^~~~~~~~~~~~~~
        {             }
../h/evar.h:219:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "and", DYNAMIC,         /* logical and */
        ^~~~~~~~~~~~~~
        {             }
../h/evar.h:220:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "ascii", MONAMIC,       /* char to integer conversion */
        ^~~~~~~~~~~~~~~~
        {               }
../h/evar.h:221:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "band", DYNAMIC,        /* bitwise and   9-10-87  jwm */
        ^~~~~~~~~~~~~~~
        {              }
../h/evar.h:222:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "bind", MONAMIC,        /* loopup what function name is bound to a key */
        ^~~~~~~~~~~~~~~
        {              }
../h/evar.h:223:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "bnot", MONAMIC,        /* bitwise not */
        ^~~~~~~~~~~~~~~
        {              }
../h/evar.h:224:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "bor", DYNAMIC,         /* bitwise or    9-10-87  jwm */
        ^~~~~~~~~~~~~~
        {             }
../h/evar.h:225:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "bxor", DYNAMIC,        /* bitwise xor   9-10-87  jwm */
        ^~~~~~~~~~~~~~~
        {              }
../h/evar.h:226:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "call", MONAMIC,        /* call a procedure */
        ^~~~~~~~~~~~~~~
        {              }
../h/evar.h:227:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "cat", DYNAMIC,         /* concatenate string */
        ^~~~~~~~~~~~~~
        {             }
../h/evar.h:228:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "chr", MONAMIC,         /* integer to char conversion */
        ^~~~~~~~~~~~~~
        {             }
../h/evar.h:229:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "divide", DYNAMIC,      /* division */
        ^~~~~~~~~~~~~~~~~
        {                }
../h/evar.h:230:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "env", MONAMIC,         /* retrieve a system environment var */
        ^~~~~~~~~~~~~~
        {             }
../h/evar.h:231:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "equal", DYNAMIC,       /* logical equality check */
        ^~~~~~~~~~~~~~~~
        {               }
../h/evar.h:232:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "exist", MONAMIC,       /* check if a file exists */
        ^~~~~~~~~~~~~~~~
        {               }
../h/evar.h:233:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "find", MONAMIC,        /* look for a file on the path... */
        ^~~~~~~~~~~~~~~
        {              }
../h/evar.h:234:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "greater", DYNAMIC,     /* logical greater than */
        ^~~~~~~~~~~~~~~~~~
        {                 }
../h/evar.h:235:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "group", MONAMIC,       /* return group match in MAGIC mode */
        ^~~~~~~~~~~~~~~~
        {               }
../h/evar.h:236:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "gtc", NILNAMIC,        /* get 1 emacs command */
        ^~~~~~~~~~~~~~~
        {              }
../h/evar.h:237:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "gtk", NILNAMIC,        /* get 1 charater */
        ^~~~~~~~~~~~~~~
        {              }
../h/evar.h:238:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "indirect", MONAMIC,    /* evaluate indirect value */
        ^~~~~~~~~~~~~~~~~~~
        {                  }
../h/evar.h:239:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "isnum", MONAMIC,       /* is the arg a number? */
        ^~~~~~~~~~~~~~~~
        {               }
../h/evar.h:240:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "left", DYNAMIC,        /* left string(string, len) */
        ^~~~~~~~~~~~~~~
        {              }
../h/evar.h:241:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "length", MONAMIC,      /* string length */
        ^~~~~~~~~~~~~~~~~
        {                }
../h/evar.h:242:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "less", DYNAMIC,        /* logical less than */
        ^~~~~~~~~~~~~~~
        {              }
../h/evar.h:243:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "lower", MONAMIC,       /* lower case string */
        ^~~~~~~~~~~~~~~~
        {               }
../h/evar.h:244:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "mid", TRINAMIC,        /* mid string(string, pos, len) */
        ^~~~~~~~~~~~~~~
        {              }
../h/evar.h:245:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "mkcol", MONAMIC,       /* column position of a mark */
        ^~~~~~~~~~~~~~~~
        {               }
../h/evar.h:246:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "mkline", MONAMIC,      /* line number of a mark */
        ^~~~~~~~~~~~~~~~~
        {                }
../h/evar.h:247:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "modulo", DYNAMIC,      /* mod */
        ^~~~~~~~~~~~~~~~~
        {                }
../h/evar.h:248:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "negate", MONAMIC,      /* negate */
        ^~~~~~~~~~~~~~~~~
        {                }
../h/evar.h:249:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "not", MONAMIC,         /* logical not */
        ^~~~~~~~~~~~~~
        {             }
../h/evar.h:250:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "or",  DYNAMIC,         /* logical or */
        ^~~~~~~~~~~~~~
        {             }
../h/evar.h:251:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "reverse", MONAMIC,     /* reverse */
        ^~~~~~~~~~~~~~~~~~
        {                 }
../h/evar.h:252:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "right", DYNAMIC,       /* right string(string, pos) */
        ^~~~~~~~~~~~~~~~
        {               }
../h/evar.h:253:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "rnd", MONAMIC,         /* get a random number */
        ^~~~~~~~~~~~~~
        {             }
../h/evar.h:254:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "sequal", DYNAMIC,      /* string logical equality check */
        ^~~~~~~~~~~~~~~~~
        {                }
../h/evar.h:255:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "sgreater", DYNAMIC,    /* string logical greater than */
        ^~~~~~~~~~~~~~~~~~~
        {                  }
../h/evar.h:256:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "sindex", DYNAMIC,      /* find the index of one string in another */
        ^~~~~~~~~~~~~~~~~
        {                }
../h/evar.h:257:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "sless", DYNAMIC,       /* string logical less than */
        ^~~~~~~~~~~~~~~~
        {               }
../h/evar.h:258:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "slower", DYNAMIC,      /* set lower to upper char translation */
        ^~~~~~~~~~~~~~~~~
        {                }
../h/evar.h:259:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "subtract", DYNAMIC,    /* subtraction */
        ^~~~~~~~~~~~~~~~~~~
        {                  }
../h/evar.h:260:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "supper", DYNAMIC,      /* set upper to lower char translation */
        ^~~~~~~~~~~~~~~~~
        {                }
../h/evar.h:261:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "times", DYNAMIC,       /* multiplication */
        ^~~~~~~~~~~~~~~~
        {               }
../h/evar.h:262:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "trim", MONAMIC,        /* trim whitespace off the end of a string */
        ^~~~~~~~~~~~~~~
        {              }
../h/evar.h:263:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "true", MONAMIC,        /* Truth of the universe logical test */
        ^~~~~~~~~~~~~~~
        {              }
../h/evar.h:264:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "upper", MONAMIC,       /* uppercase string */
        ^~~~~~~~~~~~~~~~
        {               }
../h/evar.h:265:2: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        "xlate", TRINAMIC       /* XLATE character string translation */
        ^~~~~~~~~~~~~~~~~
        {                }
../src/eval.c:92:9: warning: returning 'const char []' from a function with result type 'char *' discards qualifiers [-Wincompatible-pointer-types-discards-qualifiers]
                return(errorm);
                      ^~~~~~~~
../src/eval.c:98:10: warning: returning 'const char []' from a function with result type 'char *' discards qualifiers [-Wincompatible-pointer-types-discards-qualifiers]
                        return(errorm);
                              ^~~~~~~~
../src/eval.c:103:11: warning: returning 'const char []' from a function with result type 'char *' discards qualifiers [-Wincompatible-pointer-types-discards-qualifiers]
                                return(errorm);
                                      ^~~~~~~~
../src/eval.c:108:12: warning: returning 'const char []' from a function with result type 'char *' discards qualifiers [-Wincompatible-pointer-types-discards-qualifiers]
                                        return(errorm);
                                              ^~~~~~~~
../src/eval.c:133:12: warning: returning 'const char []' from a function with result type 'char *' discards qualifiers [-Wincompatible-pointer-types-discards-qualifiers]
                                        return(errorm);
                                              ^~~~~~~~
../src/eval.c:151:12: warning: returning 'const char []' from a function with result type 'char *' discards qualifiers [-Wincompatible-pointer-types-discards-qualifiers]
                                        return(errorm);
                                              ^~~~~~~~
../src/eval.c:168:30: warning: passing 'const char []' to parameter of type 'char *' discards qualifiers [-Wincompatible-pointer-types-discards-qualifiers]
                                        return(bytecopy(result, errorm, NSTRING * 2));
                                                                ^~~~~~
../h/eproto.h:83:52: note: passing argument to parameter 'src' here
extern char *PASCAL NEAR bytecopy(char *dst, char *src, int maxlen);
                                                   ^
../src/eval.c:213:12: warning: returning 'const char []' from a function with result type 'char *' discards qualifiers [-Wincompatible-pointer-types-discards-qualifiers]
                                        return(errorm);
                                              ^~~~~~~~
../src/eval.c:240:1: warning: non-void function does not return a value in all control paths [-Wreturn-type]
}
^
../src/eval.c:275:12: warning: returning 'const char []' from a function with result type 'char *' discards qualifiers [-Wincompatible-pointer-types-discards-qualifiers]
                                        return(errorm);
                                              ^~~~~~~~
../src/eval.c:283:8: warning: returning 'const char []' from a function with result type 'char *' discards qualifiers [-Wincompatible-pointer-types-discards-qualifiers]
        return(errorm);
              ^~~~~~~~
../src/eval.c:302:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR binary(key, tval, tlength, klength)
            ^
../src/eval.c:347:9: warning: returning 'const char []' from a function with result type 'char *' discards qualifiers [-Wincompatible-pointer-types-discards-qualifiers]
                return(errorm);
                      ^~~~~~~~
../src/eval.c:372:25: warning: returning 'const char *' from a function with result type 'char *' discards qualifiers [-Wincompatible-pointer-types-discards-qualifiers]
                case EVDESKCLR: return(cname[deskcolor]);
                                      ^~~~~~~~~~~~~~~~~~
../src/eval.c:454:1: warning: non-void function does not return a value in all control paths [-Wreturn-type]
}
^
../src/eval.c:804:8: warning: variable 'vnum' is used uninitialized whenever 'if' condition is false [-Wsometimes-uninitialized]
                        if (strcmp(&var[1], "ind") == 0) {
                            ^~~~~~~~~~~~~~~~~~~~~~~~~~~
../src/eval.c:813:21: note: uninitialized use occurs here
retvar: vd->v_num = vnum;
                    ^~~~
../src/eval.c:804:4: note: remove the 'if' if its condition is always true
                        if (strcmp(&var[1], "ind") == 0) {
                        ^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
../src/eval.c:750:19: note: initialize the variable 'vnum' to silence this warning
        register int vnum;      /* subscript in varable arrays */
                         ^
                          = 0
../src/eval.c:975:33: warning: passing 'char *' to parameter of type 'unsigned char *' converts between pointers to integer types with different sign [-Wpointer-sign]
                case EVISTERM:  isterm = stock(value);
                                               ^~~~~
../h/eproto.h:470:54: note: passing argument to parameter 'keyname' here
extern unsigned int PASCAL NEAR stock(unsigned char *keyname);
                                                     ^
../src/eval.c:1060:31: warning: passing 'char *' to parameter of type 'unsigned char *' converts between pointers to integer types with different sign [-Wpointer-sign]
                case EVSTERM:   sterm = stock(value);
                                              ^~~~~
../h/eproto.h:470:54: note: passing argument to parameter 'keyname' here
extern unsigned int PASCAL NEAR stock(unsigned char *keyname);
                                                     ^
../src/eval.c:1264:24: warning: passing 'char [128]' to parameter of type 'unsigned char *' converts between pointers to integer types with different sign [-Wpointer-sign]
                                status = getstring(buf, NSTRING, ctoec(RETCHAR));
                                                   ^~~
../h/eproto.h:172:49: note: passing argument to parameter 'buf' here
extern int PASCAL NEAR getstring(unsigned char *buf, int nbuf, int eolchar);
                                                ^
../src/eval.c:1319:1: warning: non-void function does not return a value in all control paths [-Wreturn-type]
}
^
../src/eval.c:1342:9: warning: returning 'const char []' from a function with result type 'char *' discards qualifiers [-Wincompatible-pointer-types-discards-qualifiers]
                return(truem);
                      ^~~~~~~
../src/eval.c:1344:9: warning: returning 'const char []' from a function with result type 'char *' discards qualifiers [-Wincompatible-pointer-types-discards-qualifiers]
                return(falsem);
                      ^~~~~~~~
../src/eval.c:1473:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR setwlist(wclist)
            ^
../src/eval.c:1483:10: warning: incompatible pointer to integer conversion returning 'void *' from a function with result type 'int' [-Wint-conversion]
                return NULL;
                       ^~~~
/opt/rocm-4.0.1/llvm/lib/clang/12.0.0/include/stddef.h:89:16: note: expanded from macro 'NULL'
#  define NULL ((void*)0)
               ^~~~~~~~~~
../src/eval.c:1495:9: warning: incompatible pointer to integer conversion returning 'void *' from a function with result type 'int' [-Wint-conversion]
        return NULL;
               ^~~~
/opt/rocm-4.0.1/llvm/lib/clang/12.0.0/include/stddef.h:89:16: note: expanded from macro 'NULL'
#  define NULL ((void*)0)
               ^~~~~~~~~~
../src/eval.c:1542:22: warning: '&&' within '||' [-Wlogical-op-parentheses]
        while ((*st >= '0') && (*st <= '9') ||
               ~~~~~~~~~~~~~^~~~~~~~~~~~~~~ ~~
../src/eval.c:1542:22: note: place parentheses around the '&&' expression to silence this warning
        while ((*st >= '0') && (*st <= '9') ||
                            ^
               (                           )
../src/eval.c:1608:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR desvars(f, n)
            ^
77 warnings generated.
../src/exec.c:14:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR namedcmd(f, n)
            ^
../src/exec.c:64:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR execcmd(f, n)
            ^
../src/exec.c:91:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR docmd(cline)
            ^
../src/exec.c:241:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR macarg(tok) /* get a macro line argument */
            ^
../src/exec.c:258:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR nextarg(prompt, buffer, size, terminator)
            ^
../src/exec.c:277:20: warning: passing 'char *' to parameter of type 'unsigned char *' converts between pointers to integer types with different sign [-Wpointer-sign]
                return(getstring(buffer, size, terminator));
                                 ^~~~~~
../h/eproto.h:172:49: note: passing argument to parameter 'buf' here
extern int PASCAL NEAR getstring(unsigned char *buf, int nbuf, int eolchar);
                                                ^
../src/exec.c:293:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR storeproc(f, n)
            ^
../src/exec.c:364:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR execproc(f, n)
            ^
../src/exec.c:398:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR execbuf(f, n)
            ^
../src/exec.c:439:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR dobuf(bp)
            ^
../src/exec.c:575:6: warning: variable 'ut' is used uninitialized whenever 'if' condition is true [-Wsometimes-uninitialized]
        if (scanner != NULL) {
            ^~~~~~~~~~~~~~~
../src/exec.c:937:19: note: uninitialized use occurs here
freeut: uv_head = ut->next;
                  ^~
../src/exec.c:575:2: note: remove the 'if' if its condition is always false
        if (scanner != NULL) {
        ^~~~~~~~~~~~~~~~~~~~~~
../src/exec.c:553:8: warning: variable 'ut' is used uninitialized whenever 'if' condition is true [-Wsometimes-uninitialized]
                        if (scanner == NULL) {
                            ^~~~~~~~~~~~~~~
../src/exec.c:937:19: note: uninitialized use occurs here
freeut: uv_head = ut->next;
                  ^~
../src/exec.c:553:4: note: remove the 'if' if its condition is always false
                        if (scanner == NULL) {
                        ^~~~~~~~~~~~~~~~~~~~~~
../src/exec.c:543:8: warning: variable 'ut' is used uninitialized whenever 'if' condition is true [-Wsometimes-uninitialized]
                        if (whtemp == NULL)
                            ^~~~~~~~~~~~~~
../src/exec.c:937:19: note: uninitialized use occurs here
freeut: uv_head = ut->next;
                  ^~
../src/exec.c:543:4: note: remove the 'if' if its condition is always false
                        if (whtemp == NULL)
                        ^~~~~~~~~~~~~~~~~~~
../src/exec.c:537:8: warning: variable 'ut' is used uninitialized whenever 'if' condition is true [-Wsometimes-uninitialized]
                        if (scanner == NULL) {
                            ^~~~~~~~~~~~~~~
../src/exec.c:937:19: note: uninitialized use occurs here
freeut: uv_head = ut->next;
                  ^~
../src/exec.c:537:4: note: remove the 'if' if its condition is always false
                        if (scanner == NULL) {
                        ^~~~~~~~~~~~~~~~~~~~~~
../src/exec.c:523:8: warning: variable 'ut' is used uninitialized whenever 'if' condition is true [-Wsometimes-uninitialized]
                        if (whtemp == NULL) {
                            ^~~~~~~~~~~~~~
../src/exec.c:937:19: note: uninitialized use occurs here
freeut: uv_head = ut->next;
                  ^~
../src/exec.c:523:4: note: remove the 'if' if its condition is always false
                        if (whtemp == NULL) {
                        ^~~~~~~~~~~~~~~~~~~~~
../src/exec.c:461:12: note: initialize the variable 'ut' to silence this warning
        UTABLE *ut;             /* new local user variable table */
                  ^
                   = NULL
../src/exec.c:575:6: warning: variable 'einit' is used uninitialized whenever 'if' condition is true [-Wsometimes-uninitialized]
        if (scanner != NULL) {
            ^~~~~~~~~~~~~~~
../src/exec.c:934:7: note: uninitialized use occurs here
        free(einit);
             ^~~~~
../src/exec.c:575:2: note: remove the 'if' if its condition is always false
        if (scanner != NULL) {
        ^~~~~~~~~~~~~~~~~~~~~~
../src/exec.c:553:8: warning: variable 'einit' is used uninitialized whenever 'if' condition is true [-Wsometimes-uninitialized]
                        if (scanner == NULL) {
                            ^~~~~~~~~~~~~~~
../src/exec.c:934:7: note: uninitialized use occurs here
        free(einit);
             ^~~~~
../src/exec.c:553:4: note: remove the 'if' if its condition is always false
                        if (scanner == NULL) {
                        ^~~~~~~~~~~~~~~~~~~~~~
../src/exec.c:543:8: warning: variable 'einit' is used uninitialized whenever 'if' condition is true [-Wsometimes-uninitialized]
                        if (whtemp == NULL)
                            ^~~~~~~~~~~~~~
../src/exec.c:934:7: note: uninitialized use occurs here
        free(einit);
             ^~~~~
../src/exec.c:543:4: note: remove the 'if' if its condition is always false
                        if (whtemp == NULL)
                        ^~~~~~~~~~~~~~~~~~~
../src/exec.c:537:8: warning: variable 'einit' is used uninitialized whenever 'if' condition is true [-Wsometimes-uninitialized]
                        if (scanner == NULL) {
                            ^~~~~~~~~~~~~~~
../src/exec.c:934:7: note: uninitialized use occurs here
        free(einit);
             ^~~~~
../src/exec.c:537:4: note: remove the 'if' if its condition is always false
                        if (scanner == NULL) {
                        ^~~~~~~~~~~~~~~~~~~~~~
../src/exec.c:523:8: warning: variable 'einit' is used uninitialized whenever 'if' condition is true [-Wsometimes-uninitialized]
                        if (whtemp == NULL) {
                            ^~~~~~~~~~~~~~
../src/exec.c:934:7: note: uninitialized use occurs here
        free(einit);
             ^~~~~
../src/exec.c:523:4: note: remove the 'if' if its condition is always false
                        if (whtemp == NULL) {
                        ^~~~~~~~~~~~~~~~~~~~~
../src/exec.c:457:13: note: initialize the variable 'einit' to silence this warning
        char *einit;            /* initial value of eline */
                   ^
                    = NULL
../src/exec.c:974:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR debug(bp, eline, skipflag)
            ^
../src/exec.c:1065:14: warning: passing 'char *' to parameter of type 'unsigned char *' converts between pointers to integer types with different sign [-Wpointer-sign]
                        getstring(&temp[11], NSTRING, ctoec(RETCHAR));
                                  ^~~~~~~~~
../h/eproto.h:172:49: note: passing argument to parameter 'buf' here
extern int PASCAL NEAR getstring(unsigned char *buf, int nbuf, int eolchar);
                                                ^
../src/exec.c:1081:14: warning: passing 'char [128]' to parameter of type 'unsigned char *' converts between pointers to integer types with different sign [-Wpointer-sign]
                        getstring(temp, NSTRING, ctoec(RETCHAR));
                                  ^~~~
../h/eproto.h:172:49: note: passing argument to parameter 'buf' here
extern int PASCAL NEAR getstring(unsigned char *buf, int nbuf, int eolchar);
                                                ^
../src/exec.c:1113:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR execfile(f, n)      /* execute a series of commands in a file */
            ^
../src/exec.c:1164:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR dofile(fname)
            ^
25 warnings generated.
../src/file.c:26:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR fileread(f, n)
            ^
../src/file.c:49:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR insfile(f, n)
            ^
../src/file.c:92:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR filefind(f, n)
            ^
../src/file.c:108:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR viewfile(f, n)      /* visit a file in VIEW mode */
            ^
../src/file.c:131:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR resetkey()  /* reset the encryption key if needed */
            ^
../src/file.c:164:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR getfile(fname, lockfl)
            ^
../src/file.c:255:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR readin(fname, lockfl)
            ^
../src/file.c:329:7: warning: implicit declaration of function 'access' is invalid in C99 [-Wimplicit-function-declaration]
                if (access(fname, 2 /* W_OK*/) != 0)
                    ^
../src/file.c:483:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR filewrite(f, n)
            ^
../src/file.c:506:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR fileapp(f, n)       /* append file */
            ^
../src/file.c:535:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR filesave(f, n)
            ^
../src/file.c:591:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR writeout(fn, mode)
            ^
../src/file.c:689:8: warning: implicit declaration of function 'unlink' is invalid in C99 [-Wimplicit-function-declaration]
                        if (unlink(fn) == 0 && rename(tname, fn) == 0) {
                            ^
../src/file.c:691:5: warning: implicit declaration of function 'chown' is invalid in C99 [-Wimplicit-function-declaration]
                                chown(fn, (int)st.st_uid, (int)st.st_gid);
                                ^
../src/file.c:722:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR filename(f, n)
            ^
../src/file.c:750:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR ifile(fname)
            ^
../src/file.c:862:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR showfiles(f, n)
            ^
17 warnings generated.
../src/fileio.c:31:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR ffropen(fn)
            ^
../src/fileio.c:54:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR ffwopen(fn, mode)
            ^
../src/fileio.c:94:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR ffclose()
            ^
../src/fileio.c:127:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR ffputline(buf, nbuf)
            ^
../src/fileio.c:186:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR ffgetline(nbytes)
            ^
5 warnings generated.
../src/input.c:62:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR mlyesno(prompt)
            ^
../src/input.c:109:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR mlreply(prompt, buf, nbuf)
            ^
../src/input.c:122:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR ectoc(c)
            ^
../src/input.c:139:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR ctoec(c)
            ^
../src/input.c:213:22: warning: address of array 'curbp->b_fname' will always evaluate to 'true' [-Wpointer-bool-conversion]
        if (curbp && curbp->b_fname && strcmp(curbp->b_fname, "") != 0)
                  ~~ ~~~~~~~^~~~~~~
../src/input.c:265:3: warning: add explicit braces to avoid dangling else [-Wdangling-else]
                else if (defval)
                ^
../src/input.c:1139:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR outstring(s) /* output a string of input characters */
            ^
../src/input.c:1147:1: warning: non-void function does not return a value [-Wreturn-type]
}
^
../src/input.c:1149:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR ostring(s)  /* output a string of output characters */
            ^
../src/input.c:1157:1: warning: non-void function does not return a value [-Wreturn-type]
}
^
../src/input.c:1231:15: warning: promoted type 'int' of K&R function parameter is not compatible with the parameter type 'unsigned char' declared in a previous prototype [-Wknr-promoted-parameter]
unsigned char c;        /* character to be echoed */
              ^
../h/eproto.h:156:47: note: previous declaration is here
extern int PASCAL NEAR echochar(unsigned char c);
                                              ^
11 warnings generated.
../src/isearch.c:67:13: warning: using the result of an assignment as a condition without parentheses [-Wparentheses]
        if (status = isearch(REVERSE))
            ~~~~~~~^~~~~~~~~~~~~~~~~~
../src/isearch.c:67:13: note: place parentheses around the assignment to silence this warning
        if (status = isearch(REVERSE))
                   ^
            (                        )
../src/isearch.c:67:13: note: use '==' to turn this assignment into an equality comparison
        if (status = isearch(REVERSE))
                   ^
                   ==
../src/isearch.c:82:13: warning: using the result of an assignment as a condition without parentheses [-Wparentheses]
        if (status = isearch(FORWARD))
            ~~~~~~~^~~~~~~~~~~~~~~~~~
../src/isearch.c:82:13: note: place parentheses around the assignment to silence this warning
        if (status = isearch(FORWARD))
                   ^
            (                        )
../src/isearch.c:82:13: note: use '==' to turn this assignment into an equality comparison
        if (status = isearch(FORWARD))
                   ^
                   ==
../src/isearch.c:367:11: warning: using the result of an assignment as a condition without parentheses [-Wparentheses]
                if (sts = !boundry(curline, curoff, FORWARD))
                    ~~~~^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
../src/isearch.c:367:11: note: place parentheses around the assignment to silence this warning
                if (sts = !boundry(curline, curoff, FORWARD))
                        ^
                    (                                       )
../src/isearch.c:367:11: note: use '==' to turn this assignment into an equality comparison
                if (sts = !boundry(curline, curoff, FORWARD))
                        ^
                        ==
../src/isearch.c:372:12: warning: using the result of an assignment as a condition without parentheses [-Wparentheses]
                        if (sts = eq(nextch(&curline, &curoff, FORWARD), chr))
                            ~~~~^~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
../src/isearch.c:372:12: note: place parentheses around the assignment to silence this warning
                        if (sts = eq(nextch(&curline, &curoff, FORWARD), chr))
                                ^
                            (                                                )
../src/isearch.c:372:12: note: use '==' to turn this assignment into an equality comparison
                        if (sts = eq(nextch(&curline, &curoff, FORWARD), chr))
                                ^
                                ==
4 warnings generated.
../src/keyboard.c:303:13: warning: passing 'char [128]' to parameter of type 'unsigned char *' converts between pointers to integer types with different sign [-Wpointer-sign]
        ec = stock(codeseq);
                   ^~~~~~~
../h/eproto.h:470:54: note: passing argument to parameter 'keyname' here
extern unsigned int PASCAL NEAR stock(unsigned char *keyname);
                                                     ^
../src/keyboard.c:306:17: warning: passing 'char [128]' to parameter of type 'unsigned char *' converts between pointers to integer types with different sign [-Wpointer-sign]
        return (addkey(esc_seq, ec));   /* Add to tree */
                       ^~~~~~~
../h/eproto.h:245:47: note: passing argument to parameter 'seq' here
extern int PASCAL NEAR addkey(unsigned char * seq, int fn);
                                              ^
../src/keyboard.c:407:28: warning: passing 'unsigned char *' to parameter of type 'const char *' converts between pointers to integer types with different sign [-Wpointer-sign]
        if (seq == NULL || strlen(seq) < 2)
                                  ^~~
/include/string.h:391:35: note: passing argument to parameter '__s' here
extern size_t strlen (const char *__s)
                                  ^
../src/keyboard.c:443:13: warning: passing 'unsigned char *' to parameter of type 'const char *' converts between pointers to integer types with different sign [-Wpointer-sign]
        if (strlen(seq) > NKEYSEQ - (nxtkey - keymap)) {
                   ^~~
/include/string.h:391:35: note: passing argument to parameter '__s' here
extern size_t strlen (const char *__s)
                                  ^
../src/keyboard.c:486:11: warning: implicit declaration of function 'grabwait' is invalid in C99 [-Wimplicit-function-declaration]
        qin(ch = grabwait());   /* Get first character untimed */
                 ^
../src/keyboard.c:521:10: warning: implicit declaration of function 'grabnowait' is invalid in C99 [-Wimplicit-function-declaration]
                                ch = grabnowait();
                                     ^
6 warnings generated.
../src/line.c:63:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR lfree(lp)
            ^
../src/line.c:123:1: warning: non-void function does not return a value [-Wreturn-type]
}
^
../src/line.c:132:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR lchange(flag)
            ^
../src/line.c:159:1: warning: non-void function does not return a value [-Wreturn-type]
}
^
../src/line.c:161:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR insspace(f, n)      /* insert spaces forward into text */
            ^
../src/line.c:223:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR linsert(int n, char c)
            ^
../src/line.c:344:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR lowrite(char c)
            ^
../src/line.c:473:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR ldelete(n, kflag)
            ^
../src/line.c:731:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR putctext(iline)
            ^
9 warnings generated.
../src/lock.c:182:1: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
lckhello()      /* dummy function */
^
../src/lock.c:184:1: warning: non-void function does not return a value [-Wreturn-type]
}
^
2 warnings generated.
In file included from ../src/main.c:26:
../h/ebind.h:15:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {MOUS|'m',              BINDFNC,        mmove},
                                                ^~~~~
                                                {    }
../h/ebind.h:16:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {MOUS|CTRL|'m',         BINDFNC,        mmove},
                                                ^~~~~
                                                {    }
../h/ebind.h:17:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {MOUS|SHFT|'m',         BINDFNC,        mmove},
                                                ^~~~~
                                                {    }
../h/ebind.h:18:32: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {MOUS|CTRL|SHFT|'m',    BINDFNC,        mmove},
                                                ^~~~~
                                                {    }
../h/ebind.h:19:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {MOUS|'a',              BINDFNC,        movemd},
                                                ^~~~~~
                                                {     }
../h/ebind.h:20:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {MOUS|'b',              BINDFNC,        movemu},
                                                ^~~~~~
                                                {     }
../h/ebind.h:21:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {MOUS|'e',              BINDFNC,        mregdown},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:22:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {MOUS|'f',              BINDFNC,        mregup},
                                                ^~~~~~
                                                {     }
../h/ebind.h:23:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {MOUS|'1',              BINDFNC,        resizm},
                                                ^~~~~~
                                                {     }
../h/ebind.h:26:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'A',              BINDFNC,        gotobol},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:27:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'B',              BINDFNC,        backchar},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:28:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'C',              BINDFNC,        insspace},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:29:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'D',              BINDFNC,        forwdel},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:30:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'E',              BINDFNC,        gotoeol},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:31:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'F',              BINDFNC,        forwchar},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:32:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'G',              BINDFNC,        ctrlg},
                                                ^~~~~
                                                {    }
../h/ebind.h:33:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'H',              BINDFNC,        backdel},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:34:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'I',              BINDFNC,        tab},
                                                ^~~
                                                {  }
../h/ebind.h:35:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'J',              BINDFNC,        indent},
                                                ^~~~~~
                                                {     }
../h/ebind.h:36:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'K',              BINDFNC,        killtext},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:37:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'L',              BINDFNC,        refresh},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:38:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'M',              BINDFNC,        newline},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:39:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'N',              BINDFNC,        forwline},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:40:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'O',              BINDFNC,        openline},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:41:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'P',              BINDFNC,        backline},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:42:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'Q',              BINDFNC,        quote},
                                                ^~~~~
                                                {    }
../h/ebind.h:43:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'R',              BINDFNC,        backsearch},
                                                ^~~~~~~~~~
                                                {         }
../h/ebind.h:44:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'S',              BINDFNC,        forwsearch},
                                                ^~~~~~~~~~
                                                {         }
../h/ebind.h:45:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'T',              BINDFNC,        twiddle},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:46:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'U',              BINDFNC,        unarg},
                                                ^~~~~
                                                {    }
../h/ebind.h:47:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'V',              BINDFNC,        forwpage},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:48:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'W',              BINDFNC,        killregion},
                                                ^~~~~~~~~~
                                                {         }
../h/ebind.h:49:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'X',              BINDFNC,        cex},
                                                ^~~
                                                {  }
../h/ebind.h:50:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'Y',              BINDFNC,        yank},
                                                ^~~~
                                                {   }
../h/ebind.h:51:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'Z',              BINDFNC,        backpage},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:52:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'[',              BINDFNC,        meta},
                                                ^~~~
                                                {   }
../h/ebind.h:53:24: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'\\',             BINDFNC,        forwsearch},
                                                ^~~~~~~~~~
                                                {         }
../h/ebind.h:54:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'^',              BINDFNC,        quote},
                                                ^~~~~
                                                {    }
../h/ebind.h:55:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'_',              BINDFNC,        undo},
                                                ^~~~
                                                {   }
../h/ebind.h:56:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|CTRL|'A',         BINDFNC,        fileapp},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:57:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|CTRL|'B',         BINDFNC,        listbuffers},
                                                ^~~~~~~~~~~
                                                {          }
../h/ebind.h:58:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|CTRL|'C',         BINDFNC,        quit},
                                                ^~~~
                                                {   }
../h/ebind.h:59:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|CTRL|'D',         BINDFNC,        detab},
                                                ^~~~~
                                                {    }
../h/ebind.h:60:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|CTRL|'E',         BINDFNC,        entab},
                                                ^~~~~
                                                {    }
../h/ebind.h:61:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|CTRL|'F',         BINDFNC,        filefind},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:62:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|CTRL|'I',         BINDFNC,        insfile},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:63:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|CTRL|'K',         BINDFNC,        macrotokey},
                                                ^~~~~~~~~~
                                                {         }
../h/ebind.h:64:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|CTRL|'L',         BINDFNC,        lowerregion},
                                                ^~~~~~~~~~~
                                                {          }
../h/ebind.h:65:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|CTRL|'M',         BINDFNC,        delmode},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:66:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|CTRL|'N',         BINDFNC,        mvdnwind},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:67:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|CTRL|'O',         BINDFNC,        deblank},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:68:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|CTRL|'P',         BINDFNC,        mvupwind},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:69:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|CTRL|'R',         BINDFNC,        fileread},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:70:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|CTRL|'S',         BINDFNC,        filesave},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:71:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|CTRL|'T',         BINDFNC,        trim},
                                                ^~~~
                                                {   }
../h/ebind.h:72:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|CTRL|'U',         BINDFNC,        upperregion},
                                                ^~~~~~~~~~~
                                                {          }
../h/ebind.h:73:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|CTRL|'V',         BINDFNC,        viewfile},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:74:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|CTRL|'W',         BINDFNC,        filewrite},
                                                ^~~~~~~~~
                                                {        }
../h/ebind.h:75:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|CTRL|'X',         BINDFNC,        swapmark},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:76:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|CTRL|'Z',         BINDFNC,        shrinkwind},
                                                ^~~~~~~~~~
                                                {         }
../h/ebind.h:77:29: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|CTRL|'\\',        BINDFNC,        filesave},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:78:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'?',              BINDFNC,        deskey},
                                                ^~~~~~
                                                {     }
../h/ebind.h:79:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'!',              BINDFNC,        spawn},
                                                ^~~~~
                                                {    }
../h/ebind.h:80:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'@',              BINDFNC,        pipecmd},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:81:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'#',              BINDFNC,        filter},
                                                ^~~~~~
                                                {     }
../h/ebind.h:82:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'$',              BINDFNC,        execprg},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:83:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'=',              BINDFNC,        showcpos},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:84:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'(',              BINDFNC,        ctlxlp},
                                                ^~~~~~
                                                {     }
../h/ebind.h:85:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|')',              BINDFNC,        ctlxrp},
                                                ^~~~~~
                                                {     }
../h/ebind.h:86:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'<',              BINDFNC,        narrow},
                                                ^~~~~~
                                                {     }
../h/ebind.h:87:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'>',              BINDFNC,        widen},
                                                ^~~~~
                                                {    }
../h/ebind.h:88:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'^',              BINDFNC,        enlargewind},
                                                ^~~~~~~~~~~
                                                {          }
../h/ebind.h:89:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|' ',              BINDFNC,        remmark},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:90:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'0',              BINDFNC,        delwind},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:91:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'1',              BINDFNC,        onlywind},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:92:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'2',              BINDFNC,        splitwind},
                                                ^~~~~~~~~
                                                {        }
../h/ebind.h:93:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'A',              BINDFNC,        setvar},
                                                ^~~~~~
                                                {     }
../h/ebind.h:94:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'B',              BINDFNC,        usebuffer},
                                                ^~~~~~~~~
                                                {        }
../h/ebind.h:95:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'C',              BINDFNC,        spawncli},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:97:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'D',              BINDFNC,        bktoshell},
                                                ^~~~~~~~~
                                                {        }
../h/ebind.h:99:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'E',              BINDFNC,        ctlxe},
                                                ^~~~~
                                                {    }
../h/ebind.h:100:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'G',              BINDFNC,        dispvar},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:101:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'K',              BINDFNC,        killbuffer},
                                                ^~~~~~~~~~
                                                {         }
../h/ebind.h:102:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'M',              BINDFNC,        setmod},
                                                ^~~~~~
                                                {     }
../h/ebind.h:103:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'N',              BINDFNC,        filename},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:104:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'O',              BINDFNC,        nextwind},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:105:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'P',              BINDFNC,        prevwind},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:107:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'R',              BINDFNC,        risearch},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:108:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'S',              BINDFNC,        fisearch},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:110:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'U',              BINDFNC,        undo_list},
                                                ^~~~~~~~~
                                                {        }
../h/ebind.h:111:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'W',              BINDFNC,        resize},
                                                ^~~~~~
                                                {     }
../h/ebind.h:112:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'X',              BINDFNC,        nextbuffer},
                                                ^~~~~~~~~~
                                                {         }
../h/ebind.h:113:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'Y',              BINDFNC,        cycle_ring},
                                                ^~~~~~~~~~
                                                {         }
../h/ebind.h:114:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTLX|'Z',              BINDFNC,        enlargewind},
                                                ^~~~~~~~~~~
                                                {          }
../h/ebind.h:115:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|CTRL|'C',         BINDFNC,        wordcount},
                                                ^~~~~~~~~
                                                {        }
../h/ebind.h:116:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|CTRL|'E',         BINDFNC,        execproc},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:117:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|CTRL|'F',         BINDFNC,        getfence},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:118:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|CTRL|'G',         BINDFNC,        gotomark},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:119:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|CTRL|'H',         BINDFNC,        delbword},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:120:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|CTRL|'K',         BINDFNC,        unbindkey},
                                                ^~~~~~~~~
                                                {        }
../h/ebind.h:121:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|CTRL|'L',         BINDFNC,        reposition},
                                                ^~~~~~~~~~
                                                {         }
../h/ebind.h:122:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|CTRL|'M',         BINDFNC,        delgmode},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:123:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|CTRL|'N',         BINDFNC,        namebuffer},
                                                ^~~~~~~~~~
                                                {         }
../h/ebind.h:124:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|CTRL|'R',         BINDFNC,        qreplace},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:125:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|CTRL|'S',         BINDFNC,        execfile},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:126:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|CTRL|'V',         BINDFNC,        nextdown},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:127:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|CTRL|'U',         BINDFNC,        undo_delete},
                                                ^~~~~~~~~~~
                                                {          }
../h/ebind.h:128:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|CTRL|'W',         BINDFNC,        killpara},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:129:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|CTRL|'X',         BINDFNC,        execcmd},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:130:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|CTRL|'Y',         BINDFNC,        clear_ring},
                                                ^~~~~~~~~~
                                                {         }
../h/ebind.h:131:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|CTRL|'Z',         BINDFNC,        nextup},
                                                ^~~~~~
                                                {     }
../h/ebind.h:132:29: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|CTRL|'\\',        BINDFNC,        execfile},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:133:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|' ',              BINDFNC,        setmark},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:134:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'?',              BINDFNC,        help},
                                                ^~~~
                                                {   }
../h/ebind.h:135:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'!',              BINDFNC,        reposition},
                                                ^~~~~~~~~~
                                                {         }
../h/ebind.h:136:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|')',              BINDFNC,        indent_region},
                                                ^~~~~~~~~~~~~
                                                {            }
../h/ebind.h:137:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'(',              BINDFNC,        undent_region},
                                                ^~~~~~~~~~~~~
                                                {            }
../h/ebind.h:138:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'.',              BINDFNC,        setmark},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:139:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'>',              BINDFNC,        gotoeob},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:140:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'<',              BINDFNC,        gotobob},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:141:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'~',              BINDFNC,        unmark},
                                                ^~~~~~
                                                {     }
../h/ebind.h:142:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'A',              BINDFNC,        apro},
                                                ^~~~
                                                {   }
../h/ebind.h:143:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'B',              BINDFNC,        backword},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:144:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'C',              BINDFNC,        capword},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:145:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'D',              BINDFNC,        delfword},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:147:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'E',              BINDFNC,        setekey},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:149:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'F',              BINDFNC,        forwword},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:150:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'G',              BINDFNC,        gotoline},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:151:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'K',              BINDFNC,        bindtokey},
                                                ^~~~~~~~~
                                                {        }
../h/ebind.h:152:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'L',              BINDFNC,        lowerword},
                                                ^~~~~~~~~
                                                {        }
../h/ebind.h:153:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'M',              BINDFNC,        setgmode},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:154:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'N',              BINDFNC,        gotoeop},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:155:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'P',              BINDFNC,        gotobop},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:156:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'Q',              BINDFNC,        fillpara},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:157:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'R',              BINDFNC,        sreplace},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:159:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'S',              BINDFNC,        bktoshell},
                                                ^~~~~~~~~
                                                {        }
../h/ebind.h:161:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'U',              BINDFNC,        upperword},
                                                ^~~~~~~~~
                                                {        }
../h/ebind.h:162:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'V',              BINDFNC,        backpage},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:163:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'W',              BINDFNC,        copyregion},
                                                ^~~~~~~~~~
                                                {         }
../h/ebind.h:164:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'X',              BINDFNC,        namedcmd},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:165:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'Y',              BINDFNC,        yank_pop},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:166:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {META|'Z',              BINDFNC,        quickexit},
                                                ^~~~~~~~~
                                                {        }
../h/ebind.h:169:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {ALTD|'B',              BINDFNC,        list_screens},
                                                ^~~~~~~~~~~~
                                                {           }
../h/ebind.h:170:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {ALTD|'C',              BINDFNC,        cycle_screens},
                                                ^~~~~~~~~~~~~
                                                {            }
../h/ebind.h:171:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {ALTD|'D',              BINDFNC,        delete_screen},
                                                ^~~~~~~~~~~~~
                                                {            }
../h/ebind.h:172:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {ALTD|'F',              BINDFNC,        find_screen},
                                                ^~~~~~~~~~~
                                                {          }
../h/ebind.h:173:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {ALTD|'N',              BINDFNC,        rename_screen},
                                                ^~~~~~~~~~~~~
                                                {            }
../h/ebind.h:174:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {ALTD|'R',              BINDFNC,        backhunt},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:175:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {ALTD|'S',              BINDFNC,        forwhunt},
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:177:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {SPEC|'<',              BINDFNC,        gotobob},       /* Home */
                                                ^~~~~~~
                                                {      }
../h/ebind.h:178:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {SPEC|'P',              BINDFNC,        backline},      /* up */
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:179:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {SPEC|'Z',              BINDFNC,        backpage},      /* PgUp */
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:180:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {SPEC|'B',              BINDFNC,        backchar},      /* left */
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:182:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {SPEC|'L',              BINDFNC,        reposition},    /* NP5 */
                                                ^~~~~~~~~~
                                                {         }
../h/ebind.h:184:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {SPEC|'F',              BINDFNC,        forwchar},      /* right */
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:185:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {SPEC|'>',              BINDFNC,        gotoeob},       /* End */
                                                ^~~~~~~
                                                {      }
../h/ebind.h:186:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {SPEC|'N',              BINDFNC,        forwline},      /* down */
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:187:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {SPEC|'V',              BINDFNC,        forwpage},      /* PgDn */
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:188:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {SPEC|'C',              BINDFNC,        insspace},      /* Ins */
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:189:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {SPEC|'D',              BINDFNC,        forwdel},       /* Del */
                                                ^~~~~~~
                                                {      }
../h/ebind.h:191:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {SPEC|CTRL|'B',         BINDFNC,        backword},      /* ctrl left */
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:192:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {SPEC|CTRL|'F',         BINDFNC,        forwword},      /* ctrl right */
                                                ^~~~~~~~
                                                {       }
../h/ebind.h:193:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {SPEC|CTRL|'Z',         BINDFNC,        gotobop},       /* ctrl PgUp */
                                                ^~~~~~~
                                                {      }
../h/ebind.h:194:28: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {SPEC|CTRL|'V',         BINDFNC,        gotoeop},       /* ctrl PgDn */
                                                ^~~~~~~
                                                {      }
../h/ebind.h:344:23: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {CTRL|'?',              BINDFNC,        backdel},
                                                ^~~~~~~
                                                {      }
../h/ebind.h:346:17: warning: suggest braces around initialization of subobject [-Wmissing-braces]
        {0,                     BINDNUL,        NULL}
                                                ^~~~
                                                {   }
/opt/rocm-4.0.1/llvm/lib/clang/12.0.0/include/stddef.h:89:16: note: expanded from macro 'NULL'
#  define NULL ((void*)0)
               ^~~~~~~~~~
../src/main.c:93:1: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
main(argc, argv)
^
../src/main.c:104:18: warning: incompatible function pointer types passing 'void (void)' to parameter of type '__sighandler_t' (aka 'void (*)(int)') [-Wincompatible-function-pointer-types]
        signal(SIGWINCH,winch_changed);
                        ^~~~~~~~~~~~~
/include/signal.h:88:57: note: passing argument to parameter '__handler' here
extern __sighandler_t signal (int __sig, __sighandler_t __handler)
                                                        ^
../src/main.c:464:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR editloop()
            ^
../src/main.c:599:36: warning: '&&' within '||' [-Wlogical-op-parentheses]
                while ((c = GETBASEKEY()) >= '0' && c <= '9' ||
                       ~~~~~~~~~~~~~~~~~~~~~~~~~~^~~~~~~~~~~ ~~
../src/main.c:599:36: note: place parentheses around the '&&' expression to silence this warning
                while ((c = GETBASEKEY()) >= '0' && c <= '9' ||
                                                 ^
                       (                                    )
../src/main.c:713:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR execute(c, f, n)
            ^
../src/main.c:879:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR quickexit(f, n)
            ^
../src/main.c:918:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR quit(f, n)
            ^
../src/main.c:946:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR meexit(status)
            ^
../src/main.c:963:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR ctlxlp(f, n)
            ^
../src/main.c:986:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR ctlxrp(f, n)
            ^
../src/main.c:1010:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR ctlxe(f, n)
            ^
../src/main.c:1034:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR ctrlg(f, n)
            ^
../src/main.c:1049:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR rdonly()
            ^
../src/main.c:1058:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR resterr()
            ^
../src/main.c:1075:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR meta(f, n)  /* set META prefixing pending */
            ^
../src/main.c:1086:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR cex(f, n)   /* set ^X prefixing pending */
            ^
182 warnings generated.
../src/mouse.c:32:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR movemd(f, n)
            ^
../src/mouse.c:89:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR mmove(f, n)
            ^
../src/mouse.c:149:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR mregdown(f, n)
            ^
../src/mouse.c:257:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR mregup(f, n)
            ^
../src/mouse.c:375:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR movemu(f, n)
            ^
../src/mouse.c:571:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR mouseoffset(wp, lp, col)
            ^
../src/mouse.c:607:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR mouse_screen()
            ^
../src/mouse.c:638:1: warning: non-void function does not return a value [-Wreturn-type]
}
^
../src/mouse.c:640:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR ismodeline(wp, row)
            ^
../src/mouse.c:662:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR resizm(f, n)
            ^
10 warnings generated.
../src/screen.c:69:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR cycle_screens(f, n)
            ^
../src/screen.c:85:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR find_screen(f, n)
            ^
../src/screen.c:116:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR free_screen(sp)     /* free all resouces associated with a screen */
            ^
../src/screen.c:150:1: warning: non-void function does not return a value [-Wreturn-type]
}
^
../src/screen.c:165:1: warning: non-void function does not return a value [-Wreturn-type]
}
^
../src/screen.c:167:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR delete_screen(f, n)
            ^
../src/screen.c:399:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR list_screens(f, n)
            ^
../src/screen.c:421:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR screenlist(iflag)
            ^
8 warnings generated.
../src/random.c:20:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR showcpos(f, n)
            ^
../src/random.c:127:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR getccol(bflg)
            ^
../src/random.c:185:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR setccol(pos)
            ^
../src/random.c:235:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR twiddle(f, n)
            ^
../src/random.c:290:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR quote(f, n)
            ^
../src/random.c:337:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR tab(f, n)
            ^
../src/random.c:353:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR detab(f, n)         /* change tabs to spaces */
            ^
../src/random.c:398:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR entab(f, n)         /* change spaces to tabs where posible */
            ^
../src/random.c:431:5: warning: add explicit braces to avoid dangling else [-Wdangling-else]
                                else {
                                ^
../src/random.c:475:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR trim(f, n)
            ^
../src/random.c:523:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR openline(f, n)
            ^
../src/random.c:551:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR newline(f, n)
            ^
../src/random.c:586:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR cinsert()   /* insert a newline and indentation for C */
            ^
../src/random.c:648:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR insbrace(n, c)      /* insert a brace into the text here...we are in CMODE */
            ^
../src/random.c:744:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR inspound()  /* insert a # into the text here...we are in CMODE */
            ^
../src/random.c:779:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR deblank(f, n)
            ^
../src/random.c:812:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR indent(f, n)
            ^
../src/random.c:835:5: warning: add explicit braces to avoid dangling else [-Wdangling-else]
                                else
                                ^
../src/random.c:860:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR forwdel(f, n)
            ^
../src/random.c:889:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR backdel(f, n)
            ^
../src/random.c:929:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR killtext(f, n)
            ^
../src/random.c:964:13: warning: variable 'chunk' is used uninitialized whenever 'if' condition is false [-Wsometimes-uninitialized]
        } else if (n < 0) {
                   ^~~~~
../src/random.c:974:17: note: uninitialized use occurs here
        return(ldelete(chunk, TRUE));
                       ^~~~~
../src/random.c:964:9: note: remove the 'if' if its condition is always true
        } else if (n < 0) {
               ^~~~~~~~~~~
../src/random.c:935:12: note: initialize the variable 'chunk' to silence this warning
        long chunk;
                  ^
                   = 0
../src/random.c:977:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR setmod(f, n)        /* prompt and set an editor mode */
            ^
../src/random.c:984:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR delmode(f, n)       /* prompt and delete an editor mode */
            ^
../src/random.c:991:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR setgmode(f, n)      /* prompt and set a global editor mode */
            ^
../src/random.c:998:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR delgmode(f, n)      /* prompt and delete a global editor mode */
            ^
../src/random.c:1005:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR adjustmode(kind, global)    /* change the editor mode status */
            ^
../src/random.c:1121:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR clrmes(f, n)
            ^
../src/random.c:1132:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR writemsg(f, n)
            ^
../src/random.c:1150:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR getfence(f, n)
            ^
../src/random.c:1245:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR fmatch(char ch)
            ^
../src/random.c:1321:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR istring(f, n)       
            ^
../src/random.c:1347:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR ovstring(f, n)      /* ask for and overwite a string into the current
            ^
33 warnings generated.
../src/region.c:54:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR killregion(f, n)
            ^
../src/region.c:90:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR copyregion(f, n)
            ^
../src/region.c:132:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR lowerregion(f, n)
            ^
../src/region.c:197:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR upperregion(f, n)
            ^
../src/region.c:258:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR narrow(f, n)
            ^
../src/region.c:348:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR widen(f, n)
            ^
../src/region.c:441:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR getregion(rp)
            ^
../src/region.c:542:9: warning: returning 'const char []' from a function with result type 'char *' discards qualifiers [-Wincompatible-pointer-types-discards-qualifiers]
                return(errorm);
                      ^~~~~~~~
../src/region.c:551:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR indent_region(f, n) /* indent a region n tab-stops */
            ^
../src/region.c:590:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR undent_region(f, n) /* undent a region n tab-stops */
            ^
10 warnings generated.
../src/search.c:413:15: warning: using the result of an assignment as a condition without parentheses [-Wparentheses]
                if (cl_type = (mcptr->mc_type & ALLCLOS)) {
                    ~~~~~~~~^~~~~~~~~~~~~~~~~~~~~~~~~~~~
../src/search.c:413:15: note: place parentheses around the assignment to silence this warning
                if (cl_type = (mcptr->mc_type & ALLCLOS)) {
                            ^
                    (                                   )
../src/search.c:413:15: note: use '==' to turn this assignment into an equality comparison
                if (cl_type = (mcptr->mc_type & ALLCLOS)) {
                            ^
                            ==
../src/search.c:810:13: warning: passing 'unsigned char []' to parameter of type 'char *' converts between pointers to integer types with different sign [-Wpointer-sign]
        make_delta(pat, &deltapat);
                   ^~~
../src/search.c:759:23: note: passing argument to parameter 'pstring' here
VOID make_delta(char *pstring, DELTA *tbl)
                      ^
../src/search.c:819:24: warning: promoted type 'int' of K&R function parameter is not compatible with the parameter type 'unsigned char' declared in a previous prototype [-Wknr-promoted-parameter]
register unsigned char bc;
                       ^
../h/eproto.h:158:50: note: previous declaration is here
extern int PASCAL NEAR eq(register unsigned char bc, register unsigned char pc);
                                                 ^
../src/search.c:820:24: warning: promoted type 'int' of K&R function parameter is not compatible with the parameter type 'unsigned char' declared in a previous prototype [-Wknr-promoted-parameter]
register unsigned char pc;
                       ^
../h/eproto.h:158:77: note: previous declaration is here
extern int PASCAL NEAR eq(register unsigned char bc, register unsigned char pc);
                                                                            ^
../src/search.c:884:3: warning: add explicit braces to avoid dangling else [-Wdangling-else]
                else
                ^
../src/search.c:1503:14: warning: using the result of an assignment as a condition without parentheses [-Wparentheses]
        while (pchr = *++patptr)
               ~~~~~^~~~~~~~~~~
../src/search.c:1503:14: note: place parentheses around the assignment to silence this warning
        while (pchr = *++patptr)
                    ^
               (               )
../src/search.c:1503:14: note: use '==' to turn this assignment into an equality comparison
        while (pchr = *++patptr)
                    ^
                    ==
6 warnings generated.
../src/replace.c:86:23: warning: passing 'unsigned char []' to parameter of type 'const char *' converts between pointers to integer types with different sign [-Wpointer-sign]
        nlflag = (pat[strlen(pat) - 1] == '\r');
                             ^~~
/include/string.h:391:35: note: passing argument to parameter '__s' here
extern size_t strlen (const char *__s)
                                  ^
1 warning generated.
../src/tags.c:70:1: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
newtags(path)
^
../src/tags.c:108:1: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
lookup()
^
../src/tags.c:179:1: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
restword(str, lmax)
^
../src/tags.c:210:1: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
backupword(f, n)
^
../src/tags.c:235:1: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
alterpattern(pattern)
^
../src/tags.c:301:1: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
tagger(errmsg, retag)
^
../src/tags.c:32:13: warning: unused variable 'SVER' [-Wunused-variable]
static char SVER[] = "@(#) %M% %I% %H%";
            ^
7 warnings generated.
../src/undo.c:266:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR undolist()
            ^
../src/undo.c:451:1: warning: non-void function does not return a value in all control paths [-Wreturn-type]
}
^
../src/undo.c:514:1: warning: non-void function does not return a value in all control paths [-Wreturn-type]
}
^
3 warnings generated.
../src/unix.c:681:17: warning: array index 256 is past the end of the array (which contains 64 elements) [-Warray-bounds]
        if (inbuft == &inbuf[sizeof(inbuf)]) {
                       ^     ~~~~~~~~~~~~~
../src/unix.c:307:1: note: array 'inbuf' declared here
static int inbuf[NINCHAR];              /* Input buffer                 */
^
../src/unix.c:766:2: warning: implicit declaration of function 'tputs' is invalid in C99 [-Wimplicit-function-declaration]
        tputs(seq, 1, ttputc);
        ^
../src/unix.c:807:11: warning: implicit declaration of function 'tgetent' is invalid in C99 [-Wimplicit-function-declaration]
        status = tgetent(tcbuf, cp);
                 ^
../src/unix.c:824:6: warning: format specifies type 'int *' but the argument has type 'short *' [-Wformat]
            &term.t_nrow) != 1)
            ^~~~~~~~~~~~
../src/unix.c:825:17: warning: implicit declaration of function 'tgetnum' is invalid in C99 [-Wimplicit-function-declaration]
                term.t_nrow = tgetnum("li");
                              ^
../src/unix.c:829:6: warning: format specifies type 'int *' but the argument has type 'short *' [-Wformat]
            &term.t_ncol) != 1)
            ^~~~~~~~~~~~
../src/unix.c:876:10: warning: passing 'char *' to parameter of type 'unsigned char *' converts between pointers to integer types with different sign [-Wpointer-sign]
                addkey(TGETSTR(kp->name, &cp), kp->value);
                       ^~~~~~~~~~~~~~~~~~~~~~
../src/unix.c:783:22: note: expanded from macro 'TGETSTR'
#define TGETSTR(a,b)    tgetstr((a), (b))
                        ^~~~~~~~~~~~~~~~~
../h/eproto.h:245:47: note: passing argument to parameter 'seq' here
extern int PASCAL NEAR addkey(unsigned char * seq, int fn);
                                              ^
../src/unix.c:881:11: warning: implicit declaration of function 'tgetflag' is invalid in C99 [-Wimplicit-function-declaration]
        hpterm = tgetflag("xs");
                 ^
../src/unix.c:969:1: warning: non-void function does not return a value [-Wreturn-type]
}
^
../src/unix.c:981:1: warning: non-void function does not return a value [-Wreturn-type]
}
^
../src/unix.c:1076:1: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
scbeep()
^
../src/unix.c:1191:16: warning: passing 'char *' to parameter of type 'unsigned char *' converts between pointers to integer types with different sign [-Wpointer-sign]
                code = stock(cmd);
                             ^~~
../h/eproto.h:470:54: note: passing argument to parameter 'keyname' here
extern unsigned int PASCAL NEAR stock(unsigned char *keyname);
                                                     ^
../src/unix.c:1194:10: warning: passing 'char *' to parameter of type 'unsigned char *' converts between pointers to integer types with different sign [-Wpointer-sign]
                addkey(cp, code);
                       ^~
../h/eproto.h:245:47: note: passing argument to parameter 'seq' here
extern int PASCAL NEAR addkey(unsigned char * seq, int fn);
                                              ^
../src/unix.c:1249:2: warning: implicit declaration of function 'time' is invalid in C99 [-Wimplicit-function-declaration]
        time(&buf);
        ^
../src/unix.c:1566:6: warning: unused variable 'index' [-Wunused-variable]
        int index;
            ^
../src/unix.c:1721:18: warning: incompatible function pointer types passing 'void (void)' to parameter of type '__sighandler_t' (aka 'void (*)(int)') [-Wincompatible-function-pointer-types]
        signal(SIGWINCH,winch_changed);
                        ^~~~~~~~~~~~~
/include/signal.h:88:57: note: passing argument to parameter '__handler' here
extern __sighandler_t signal (int __sig, __sighandler_t __handler)
                                                        ^
../src/unix.c:1732:2: warning: implicit declaration of function 'winch_vtresize' is invalid in C99 [-Wimplicit-function-declaration]
        winch_vtresize(win.ws_row,win.ws_col);
        ^
../src/unix.c:1727:11: warning: unused variable 'wp' [-Wunused-variable]
        EWINDOW *wp;
                 ^
../src/unix.c:1098:13: warning: unused variable 'cmap' [-Wunused-variable]
static char cmap[8] = { 0, 4, 2, 6, 1, 5, 3, 7 };
            ^
19 warnings generated.
../src/window.c:18:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR reposition(f, n)
            ^
../src/window.c:34:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR refresh(f, n)
            ^
../src/window.c:57:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR nextwind(f, n)
            ^
../src/window.c:104:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR prevwind(f, n)
            ^
../src/window.c:138:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR mvdnwind(f, n)
            ^
../src/window.c:153:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR mvupwind(f, n)
            ^
../src/window.c:200:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR onlywind(f, n)
            ^
../src/window.c:256:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR delwind(f,n)
            ^
../src/window.c:343:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR splitwind(f, n)
            ^
../src/window.c:435:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR enlargewind(f, n)
            ^
../src/window.c:486:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR shrinkwind(f, n)
            ^
../src/window.c:534:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR resize(f, n)
            ^
../src/window.c:620:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR nextup(f, n)        /* scroll the next window up (back) a page */
            ^
../src/window.c:628:1: warning: non-void function does not return a value [-Wreturn-type]
}
^
../src/window.c:630:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR nextdown(f, n)      /* scroll the next window down (forward) a page */
            ^
../src/window.c:638:1: warning: non-void function does not return a value [-Wreturn-type]
}
^
../src/window.c:640:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR savewnd(f, n)       /* save ptr to current window */
            ^
../src/window.c:649:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR restwnd(f, n)       /* restore the saved screen */
            ^
../src/window.c:673:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR newsize(f, n)       /* resize the screen, re-writing the screen */
            ^
../src/window.c:744:6: warning: misleading indentation; statement is not part of the previous 'if' [-Wmisleading-indentation]
                                        curbp = curwp->w_bufp;
                                        ^
../src/window.c:742:5: note: previous statement is here
                                if (wp == curwp)
                                ^
../src/window.c:775:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR newwidth(f, n)      /* resize the screen, re-writing the screen */
            ^
../src/window.c:814:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR new_col_org(f, n)   /* reposition the screen, re-writing the screen */
            ^
../src/window.c:841:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR new_row_org(f, n)   /* reposition the screen, re-writing the screen */
            ^
23 warnings generated.
../src/word.c:21:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR wrapword(f, n)
            ^
../src/word.c:77:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR backword(f, n)
            ^
../src/word.c:103:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR forwword(f, n)
            ^
../src/word.c:130:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR endword(f, n)
            ^
../src/word.c:158:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR upperword(f, n)
            ^
../src/word.c:195:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR lowerword(f, n)
            ^
../src/word.c:233:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR capword(f, n)
            ^
../src/word.c:283:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR delfword(f, n)
            ^
../src/word.c:375:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR delbword(f, n)
            ^
../src/word.c:440:6: warning: promoted type 'int' of K&R function parameter is not compatible with the parameter type 'char' declared in a previous prototype [-Wknr-promoted-parameter]
char c;
     ^
../h/eproto.h:344:38: note: previous declaration is here
extern int PASCAL NEAR isinword(char c);
                                     ^
../src/word.c:445:18: warning: array subscript is of type 'char' [-Wchar-subscripts]
                return(wordlist[c]);
                               ^~
../src/word.c:457:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR fillpara(f, n)      /* Fill the current paragraph according to the
            ^
../src/word.c:603:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR killpara(f, n)      /* delete n paragraphs starting with the current one */
            ^
../src/word.c:638:13: warning: type specifier missing, defaults to 'int' [-Wimplicit-int]
PASCAL NEAR wordcount(f, n)
            ^
14 warnings generated.
