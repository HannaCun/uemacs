/*	Definitions for D1		*/

/* menu definitions */

#define	M_FILES_SAVE	701
#define	M_FILES_SAVEAS	702
#define	M_FILES_CLOSE	703

#define M_FILE_WRITEALL	801

#define	ABANDON_MENU	901
#define AM_SAVE		1
#define	AM_CANCEL	2
#define	AM_ABANDON	4
#define	AM_NAME		5

#if	0
#define M_FILE			256
#define M_FILE_NEW		257
#define M_FILE_OPEN 		258
#define M_FILE_QUIT 		268
#define M_FILE_ABOUT		271
#endif
#define	M_FILE_SAVEAS		272

#define	MAIN_MENUBAR		5001
#define	BUF_MENUBAR		5002
